/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.vali0066.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;


/**
 *
 * @author Rizel Valiente
 * 
 */

/**
 * Sprite class sets the properties of a sprite
 * having the x and y position and the speed 
 * Sprite field id is auto generated
 * includes methods that makes the sprite behave when they hit the walls
 */
@Entity
@Table(name = "SPRITE")
@NamedQueries({
@NamedQuery(name = "Sprite.findAll", query = "SELECT s FROM Sprite s"),
@NamedQuery(name = "Sprite.findById", query = "SELECT s FROM Sprite s WHERE s.id = :id"),
@NamedQuery(name = "Sprite.findByx", query = "SELECT s FROM Sprite s WHERE s.x = :x"),
@NamedQuery(name = "Sprite.findByy", query = "SELECT s FROM Sprite s WHERE s.y = :y"),
@NamedQuery(name = "Sprite.findByxSpeed", query = "SELECT s FROM Sprite s WHERE s.xSpeed = :xSpeed"),
@NamedQuery(name = "Sprite.findByySpeed", query = "SELECT s FROM Sprite s WHERE s.ySpeed = :ySpeed")
})

public class Sprite implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @NotNull
    @Min(0)
    private Integer x;
    
    @NotNull
    @Min(0)
    private Integer y;
    
    @NotNull
    private Integer xSpeed;
    
    @NotNull
    private Integer ySpeed;
    
    public Sprite(){
        
    }

    public Sprite(Long id){
        this.id = id;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getX() {
        return x;
    }
    
     public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }
    
     public void setY(Integer y) {
        this.y = y;
    }

    public Integer getxSpeed() {
        return xSpeed;
    }
    
    public void setxSpeed(Integer xSpeed) {
        this.xSpeed = xSpeed;
    }

    public Integer getySpeed() {
        return ySpeed;
    }
    
    public void setySpeed(Integer ySpeed) {
        this.ySpeed = ySpeed;
    }
     
    public void move(){
        x+= xSpeed;
        y+= ySpeed;
    }
    
      
   public Integer moveX(Integer x, Integer xSpeed){
        x+= xSpeed;
        return x;
    }    
    
    public Integer moveY(Integer y, Integer ySpeed){
         y+= ySpeed;
        return y;
    }
    
    public void bounceTopWall(){
        ySpeed = - ySpeed;
    }
    
    public void bounceBottomWall(){
         ySpeed = - ySpeed;
    }
     
    public void bounceLeftWall(){     
        xSpeed = -xSpeed;
    }
     
    public void bounceRightWall(){
        xSpeed = -xSpeed;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sprite)) {
            return false;
        }
        Sprite other = (Sprite) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cst8218.vali0066.entity.Sprite[ id=" + id + " ]";
    }
    
}