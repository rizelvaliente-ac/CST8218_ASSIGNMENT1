package com.mycompany.spriterizel.resources;

import cst8218.vali0066.entity.Sprite;
import cst8218.vali0066.game.GameSession;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

/**
 *
 * @author 
 */
@Path("javaee8")
public class JavaEE8Resource {
     
      
    @GET
    public Response ping(){
        return Response
                .ok("ping")
                .build();
    }

}
