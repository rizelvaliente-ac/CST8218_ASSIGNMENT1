/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import cst8218.vali0066.entity.Sprite;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Rizel
 */
public class SpriteTest {
    
    public SpriteTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of move method, of class Sprite.
     */    
    @Test
     public void testMoveX(){
         System.out.println("move x");
         Sprite s = new Sprite();
         Integer x= new Integer(5);
         Integer xSpeed= new Integer(10);         
         
         int expResult = 15;
         Integer result = s.moveX(x, xSpeed);
         assertEquals(expResult, result);
         
     }
     

@Test
     public void testMoveY(){
         System.out.println("move y");
         Sprite s = new Sprite();
         Integer y= new Integer(5);
         Integer ySpeed= new Integer(10);         
         
         int expResult = 15;
         Integer result = s.moveY(y, ySpeed);
         assertEquals(expResult, result);
         
     }
     
    
}
