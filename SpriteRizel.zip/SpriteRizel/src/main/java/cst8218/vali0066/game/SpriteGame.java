/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.vali0066.game;

import com.mycompany.spriterizel.SpriteFacade;
import cst8218.vali0066.entity.Sprite;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

/**
 *
 * @author Rizel Valiente
 * this class is the main program
 * 
 * 
 */
@Startup
@Singleton
public class SpriteGame {
    
    private Integer x_size = 500;
    private Integer y_size = 500;
    
    @EJB
    private SpriteFacade spriteFacade;
    
    private List<Sprite> spriteList;
    
    @Inject
    private GameSession session;
    
   /**
    * go() makes all the sprite move in the program
    */    
    @PostConstruct
    public void go(){
        new Thread (new Runnable(){      //set up a thread
            public void run(){      
                while(true){              //infinite loop
                    //tell all sprites to move
                    spriteList = session.findAll();       //retrieve all sprites
                        for(Sprite s: spriteList){
                        s.move();           //move sprites
                        doBounce(s);       
                        session.edit(s);   //update the database
                        }
                        //determine which sprites should bounce, and ask to bounce
                        try{
                            Thread.sleep(100);  //pause 1/10 of a second
                        }catch(InterruptedException e){
                            e.printStackTrace();
                        }
                }
            }
        }
        ).start();
    }//end go() 
    
    private void doBounce(Sprite s){
        if(s.getX() < 0 && s.getxSpeed() < 0){
            //bounce off the left wall
            s.bounceLeftWall();
        }
        
        if(s.getY() < 0 && s.getySpeed()<0){
            //bounce off the top wall
            s.bounceTopWall();
        }
        
        if(s.getX() > x_size && s.getxSpeed() > 0){
             //bounce off the Right wall
            s.bounceRightWall();
        }
        
        if(s.getY()> y_size && s.getySpeed() > 0){
             //bounce off the Bottom wall
            s.bounceBottomWall();
        }
    }   
}


