/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.vali0066.game;

import com.mycompany.spriterizel.AbstractFacade;
import cst8218.vali0066.entity.Sprite;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 *
 * @author Rizel Valiente
 * Game session 
 * sets up the entity manager that can perform the methods to an entity or all 
 * entities in the database
 * 
 */
@Stateless
public class GameSession{

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

 protected EntityManager getEntityManager() {
        return em;
    }
    public void edit(Sprite entity) {
        getEntityManager().merge(entity);
    }
    
    //return list of sprites from database
    public List<Sprite> findAll() {
        javax.persistence.criteria.CriteriaQuery cq = getEntityManager().getCriteriaBuilder().createQuery();
        cq.select(cq.from(Sprite.class));
        return getEntityManager().createQuery(cq).getResultList();
    }
    
     public int count() {
        javax.persistence.criteria.CriteriaQuery cq = getEntityManager().getCriteriaBuilder().createQuery();
        javax.persistence.criteria.Root<Sprite> rt = cq.from(Sprite.class);
        cq.select(getEntityManager().getCriteriaBuilder().count(rt));
        javax.persistence.Query q = getEntityManager().createQuery(cq);
        return ((Long) q.getSingleResult()).intValue();
    }
     
        public void create(Sprite entity) {
        getEntityManager().persist(entity);
    }

    public void remove(Sprite entity) {
        getEntityManager().remove(getEntityManager().merge(entity));
    }
   
}