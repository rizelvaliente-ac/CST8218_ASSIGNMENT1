/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.game;

import cst8218.entity.Sprite;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Nathan MacDonnell
 */
//class GameSession. implements entity manager that can perform methods on sprite entity
@Stateless
public class GameSession {
 @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

   
    protected EntityManager getEntityManager() {
        return em;
    }
    
    public List<Sprite> findAll() {
        javax.persistence.criteria.CriteriaQuery cq = getEntityManager().getCriteriaBuilder().createQuery();
        cq.select(cq.from(Sprite.class));
        return getEntityManager().createQuery(cq).getResultList();
    }
   
    public void edit(Sprite entity) {
        getEntityManager().merge(entity);
    }
    
     public void remove(Sprite entity) {
        getEntityManager().remove(getEntityManager().merge(entity));
    }
     
       public void create(Sprite entity) {
        getEntityManager().persist(entity);
    }
       
    public int count() {
        javax.persistence.criteria.CriteriaQuery cq = getEntityManager().getCriteriaBuilder().createQuery();
        javax.persistence.criteria.Root<Sprite> rt = cq.from(Sprite.class);
        cq.select(getEntityManager().getCriteriaBuilder().count(rt));
        javax.persistence.Query q = getEntityManager().createQuery(cq);
        return ((Long) q.getSingleResult()).intValue();
    }
      
}
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

