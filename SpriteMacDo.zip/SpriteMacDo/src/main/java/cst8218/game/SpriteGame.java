/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.game;

import com.mycompany.spritemacdo.SpriteFacade;
import cst8218.entity.Sprite;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.inject.Inject;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


/**
 *
 * @author Nathan MacDonnell
 */
//Class SpriteGame is the main() program
@Singleton
public class SpriteGame {

     private Integer xSize = 500;
    private Integer ySize = 500;
    
    private List<Sprite> spriteList;
    
    @Inject
    private GameSession session;
    
   
    //  set up a thread
    //      retrieve all sprites
    //      move sprites
    //      pause 1/10 of a second
       private void doBounce(Sprite s){
                            if (s.getX() < 0 && s.getxSpeed() < 0) {
                                s.bounceLeftWall();
                            }
                             if (s.getY() < 0 && s.getySpeed() < 0) {
                                s.bounceTopWall();
                            }
                             if (s.getX() > xSize && s.getxSpeed() > 0) {
                                s.bounceRightWall();
                            }
                             if (s.getY() > ySize && s.getySpeed() > 0) {
                                s.bounceBottomWall();
                            }
                             
       }                        
   // new Thread(new Runnable(){@Override public void run(){{}).start();
    @PostConstruct
    public void go() {
        new Thread(new Runnable() {
            public void run() {

                while (true) {
                    spriteList = session.findAll();
                    //add the code to tell all sprites to move
                    for (Sprite s : spriteList) {
                        s.move();
                        doBounce(s);
                        session.edit(s);
                    }
                    //add the code to determine which sprites should bounce, and ask them to bounce

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
        ).start();
    }
}
