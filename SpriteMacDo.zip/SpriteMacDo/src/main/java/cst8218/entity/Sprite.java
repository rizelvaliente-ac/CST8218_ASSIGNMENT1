/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Nathan MacDonnell
 */
@Entity
@Table(name = "SPRITE")
@XmlRootElement
@NamedQueries({
   
@NamedQuery(name = "Sprite.findAll", query = "SELECT s FROM Sprite s"),
@NamedQuery(name = "Sprite.findById", query = "SELECT s FROM Sprite s WHERE s.id = :id"),
@NamedQuery(name = "Sprite.findByx", query = "SELECT s FROM Sprite s WHERE s.x = :x"),
@NamedQuery(name = "Sprite.findByy", query = "SELECT s FROM Sprite s WHERE s.y = :y"),
@NamedQuery(name = "Sprite.findByxSpeed", query = "SELECT s FROM Sprite s WHERE s.xSpeed = :xSpeed"),
@NamedQuery(name = "Sprite.findByySpeed", query = "SELECT s FROM Sprite s WHERE s.ySpeed = :ySpeed")
})
  
//Sprite Bean class. sets a sprite enity with variables and primary key.
// Sprite Id auto gnerated
// Sprite has x and y variables including speed
//includes methods to manipulate the sprite when hitting walls on web application
public class Sprite implements Serializable {

   private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @NotNull
    @Min(0)
    private Integer x;
    
    @NotNull
    @Min(0)
    private Integer y;
    
    @NotNull
    private Integer xSpeed;
    
    @NotNull
    private Integer ySpeed;
    
    public Integer getX() {
        return x;
    }

    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public Integer getxSpeed() {
        return xSpeed;
    }

    public void setxSpeed(Integer xSpeed) {
        this.xSpeed = xSpeed;
    }

    public Integer getySpeed() {
        return ySpeed;
    }

    public void setySpeed(Integer ySpeed) {
        this.ySpeed = ySpeed;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    //method move() will move the location of the sprites on the application by  x and y variables
    public void move(){
        x+=xSpeed;
        y+=ySpeed;
    }
    
    /**
    * use to JUnit test move x    
    */   
   public Integer moveX(Integer x, Integer xSpeed){
        x+= xSpeed;
        return x;
    }    
   
   /**
    * use to JUnit test move y    
    */   
    public Integer moveY(Integer y, Integer ySpeed){
         y+= ySpeed;
        return y;
    }
    
    //method to bounce sprite when reaches top wall on web application
    public void bounceTopWall(){
        ySpeed = - ySpeed;
    }
    //method to bounce sprite when reaches bottom wall on web application
    public void bounceBottomWall(){
        ySpeed = - ySpeed;
    }
    //method to bounce sprite when reaches left wall on web application
    public void bounceLeftWall(){
        xSpeed = - xSpeed;
    }
    //method to bounce sprite when reaches right wall on web application
    public void bounceRightWall(){
        xSpeed = - xSpeed;
    }
    //method to update new Sprite with values of old Sprite
    //method update sprite old values with new ones and leaves the untouched values.
    public void update(Sprite entity){
        //new.update(old sprite)
        if (getX()!= null ){
            entity.setX(getX());
        }
        if (getY()!=null){
            entity.setY(getY());
        }
        if (getxSpeed()!=null){
            entity.setxSpeed(getxSpeed());
        }
        if (getySpeed()!=null){
            entity.setySpeed(getySpeed());
        }
          //old Sprite is managed by entity manager. Old Sprite values saved
        }
    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sprite)) {
            return false;
        }
        Sprite other = (Sprite) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cst8218.entity.Sprite[ id=" + id + " ]";
    }
    
}
