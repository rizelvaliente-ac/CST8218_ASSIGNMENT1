/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.entity;

import java.util.List;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author Nathan MacDonnell
 */

// SpriteFacadeRest class able to manipulate entities in the Table within the database through HTTP request through web application
//implements Stateless annotation 
@Stateless
@DeclareRoles({"RestGroup", "Admin", "Regular"})
@RolesAllowed({"Admin", "RestGroup"})
@Path("cst8218.entity.sprite")
public class SpriteFacadeREST extends AbstractFacade<Sprite> {

 
    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    public SpriteFacadeREST() {
        super(Sprite.class);
    }

    //Send HTTP POST request on the root resource to create a new sprite in Table
    // Return OK status if sprite was created
    @POST
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response createSprite(Sprite entity) {
        //Creates the new sprite if id is null, and returns the created sprite
        if(entity.getId()== null){
           
            super.create(entity);
            return Response.status(Response.Status.CREATED).entity(entity).build();
        }
        //Updates an existing sprite if id is not null and exists
        if(entity.getId()!= null || super.find(entity.getId())!=null){
            Sprite old = super.find(entity.getId());
            entity.update(old);
           return Response.status(Response.Status.OK).entity(old).build(); 
        }
        //It is an invalid request if the id is not null and a Sprite with that id does not exist
        if(entity.getId()== null || super.find(entity.getId())==null){
        return Response.status(Response.Status.BAD_REQUEST).entity(Sprite.class).build(); 
        }
        return Response.status(Response.Status.OK).entity(entity).build();
    }
    
    //Send HTTP POST request on specefic id to change the variables of the Sprite 
    // with matching id, with the new non-null information given by the Sprite in the body of the request
    // Return OK status if sprite variables was succesfully changed by with variables of new sprite in the body of the request
    @POST
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response update(@PathParam("id") Long id, Sprite entity) {
        //It’s an error if the id doesn’t exist, or if the Sprite in the body of the request has a non-matching id
        if (entity.getId()== null || super.find(entity.getId())==null) {
            return Response.status(Response.Status.BAD_REQUEST).entity(entity).build();
        }
        //Old values should be preserved if they are not overwritten by the new changes.  Consider adding a method
        //to the Sprite class so that the method can be called on the old Sprite with a new Sprite as an argument. 
        //Perhaps newSprite.updates(oldSprite), updates the old Sprite with all the non-null new Sprite values
        //newSprite.updates(oldSprite)
         Sprite old = super.find(entity.getId());
            entity.update(old);
            
        
        return Response.status(Response.Status.OK).entity(old).build();
    }
    
    //Send HTTP PUT request on specefic id to replace the sprite with matching id with the sprite in the body of the request 
    // Return OK status if sprite  was succesfully replaced with the sprite in the body of the request
    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response edit(@PathParam("id") Long id, Sprite entity) {
        //It is an invalid request if the Sprite with that id doesn’t exist, or if the Sprite in the body has a non-matching id
        if (entity.getId()== null || !entity.getId().equals(id)|| super.find(entity.getId())==null ) {
            return Response.status(Response.Status.BAD_REQUEST).entity(entity).build();
        }
        //The old Sprite is replaced by the new Sprite, so only the new values should remain in the result that is stored in the database.
        super.edit(entity);
        return Response.status(Response.Status.OK).entity(entity).build();
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Long id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Sprite find(@PathParam("id") Long id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Sprite> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Sprite> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
