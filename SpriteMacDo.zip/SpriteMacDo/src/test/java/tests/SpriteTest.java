/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import cst8218.entity.Sprite;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Rizel
 */
public class SpriteTest {
    
    public SpriteTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of move x method, of class Sprite.
     */    
    @Test
     public void testMoveX(){
         System.out.println("move x");
         Sprite s = new Sprite();   //create a new object sprite
        
         Integer x= new Integer(5); //a given x value
         Integer xSpeed= new Integer(10);         //a given xSpeed value
         
         int expResult = 15;        //expected result
         
         Integer result = s.moveX(x, xSpeed);   //the actual result 
         assertEquals(expResult, result);   //assert to compare the results         
     }
     
    /**
     * Test of move x method, of class Sprite.
     */
    @Test
     public void testMoveY(){
         System.out.println("move y");
         Sprite s = new Sprite();  //create a new object sprite
         Integer y= new Integer(5); // a given y value
         Integer ySpeed= new Integer(10);  //a given ySpeed value       
         
         int expResult = 15;        //expected result
         Integer result = s.moveY(y, ySpeed);   //the actual result
         assertEquals(expResult, result);   //assert to compare the results
         
     }
  
}
